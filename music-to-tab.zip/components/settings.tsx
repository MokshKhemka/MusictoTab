import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"

export function Settings() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Display Preferences</CardTitle>
          <CardDescription>Customize how tabs are displayed</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-2">
            <Label htmlFor="notation">Notation Style</Label>
            <RadioGroup defaultValue="standard" className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="standard" id="standard" />
                <Label htmlFor="standard">Standard</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="numeric" id="numeric" />
                <Label htmlFor="numeric">Numeric</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="sheet" id="sheet" />
                <Label htmlFor="sheet">Sheet Music</Label>
              </div>
            </RadioGroup>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="font-size">Font Size</Label>
            <Select defaultValue="medium">
              <SelectTrigger>
                <SelectValue placeholder="Select font size" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="small">Small</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="large">Large</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-between">
            <Label htmlFor="show-fretboard">Show Fretboard Diagram</Label>
            <Switch id="show-fretboard" defaultChecked />
          </div>

          <div className="flex items-center justify-between">
            <Label htmlFor="show-finger-numbers">Show Finger Numbers</Label>
            <Switch id="show-finger-numbers" defaultChecked />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Conversion Settings</CardTitle>
          <CardDescription>Adjust how music is converted to tabs</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-2">
            <Label htmlFor="complexity">Complexity Level</Label>
            <Select defaultValue="medium">
              <SelectTrigger>
                <SelectValue placeholder="Select complexity" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="beginner">Beginner (Simplified)</SelectItem>
                <SelectItem value="medium">Intermediate</SelectItem>
                <SelectItem value="advanced">Advanced (Full Detail)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="api-key">API Key (Optional)</Label>
            <Input id="api-key" type="password" placeholder="Enter your API key" />
            <p className="text-xs text-slate-500">For premium users with higher conversion limits</p>
          </div>

          <div className="flex items-center justify-between">
            <Label htmlFor="auto-save">Auto-save Conversions</Label>
            <Switch id="auto-save" defaultChecked />
          </div>
        </CardContent>
        <CardFooter>
          <Button className="w-full">Save Settings</Button>
        </CardFooter>
      </Card>
    </div>
  )
}
