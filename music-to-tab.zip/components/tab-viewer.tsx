"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Download, Play, Printer, Share2 } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function TabViewer() {
  const [instrument, setInstrument] = useState("guitar")
  const [tuning, setTuning] = useState("standard")
  const [tempo, setTempo] = useState(100)

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle>Tab Viewer</CardTitle>
        <CardDescription>View and customize your generated tab</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="grid gap-2">
            <Select value={instrument} onValueChange={setInstrument}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Instrument" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="guitar">Guitar</SelectItem>
                <SelectItem value="bass">Bass</SelectItem>
                <SelectItem value="ukulele">Ukulele</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid gap-2">
            <Select value={tuning} onValueChange={setTuning}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Tuning" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="standard">Standard (E A D G B E)</SelectItem>
                <SelectItem value="dropD">Drop D (D A D G B E)</SelectItem>
                <SelectItem value="openG">Open G (D G D G B D)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex justify-between">
            <span className="text-sm">Tempo</span>
            <span className="text-sm font-medium">{tempo} BPM</span>
          </div>
          <Slider value={[tempo]} min={60} max={200} step={1} onValueChange={(value) => setTempo(value[0])} />
        </div>

        <Tabs defaultValue="tab" className="w-full">
          <TabsList className="grid grid-cols-2">
            <TabsTrigger value="tab">Tab</TabsTrigger>
            <TabsTrigger value="chord">Chord Chart</TabsTrigger>
          </TabsList>

          <TabsContent value="tab" className="pt-4">
            <div className="bg-white dark:bg-slate-900 border rounded-md p-4 font-mono text-sm overflow-x-auto whitespace-nowrap">
              <pre className="text-xs sm:text-sm">
                {`e|---0-----0-----0-----0-----0-----0-----0-----0-----|
B|---1-----1-----1-----1-----1-----1-----1-----1-----|
G|---0-----0-----0-----0-----0-----0-----0-----0-----|
D|---2-----2-----2-----2-----2-----2-----2-----2-----|
A|---3-----3-----3-----3-----3-----3-----3-----3-----|
E|-----------------------------------------------0---|

e|---0-----0-----0-----0-----0-----0-----0-----0-----|
B|---1-----1-----1-----1-----1-----1-----1-----1-----|
G|---0-----0-----0-----0-----0-----0-----0-----0-----|
D|---2-----2-----2-----2-----2-----2-----2-----2-----|
A|---3-----3-----3-----3-----3-----3-----3-----3-----|
E|-----------------------------------------------0---|`}
              </pre>
            </div>
          </TabsContent>

          <TabsContent value="chord" className="pt-4">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {["G", "C", "D", "Em"].map((chord) => (
                <div key={chord} className="flex flex-col items-center">
                  <div className="text-lg font-bold mb-1">{chord}</div>
                  <div className="w-16 h-20 bg-slate-100 dark:bg-slate-800 rounded flex items-center justify-center">
                    {/* Chord diagram would go here */}
                    <span className="text-xs text-slate-500">Chord diagram</span>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="flex flex-wrap gap-2 justify-between">
        <div className="flex gap-2">
          <Button size="sm" variant="outline">
            <Play className="h-4 w-4 mr-1" />
            Play
          </Button>
          <Button size="sm" variant="outline">
            <Printer className="h-4 w-4 mr-1" />
            Print
          </Button>
        </div>
        <div className="flex gap-2">
          <Button size="sm" variant="outline">
            <Share2 className="h-4 w-4 mr-1" />
            Share
          </Button>
          <Button size="sm">
            <Download className="h-4 w-4 mr-1" />
            Download
          </Button>
        </div>
      </CardFooter>
    </Card>
  )
}
