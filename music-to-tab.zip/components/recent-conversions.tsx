import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Clock, Download, ExternalLink, Music } from "lucide-react"

export function RecentConversions() {
  const recentItems = [
    { id: 1, title: "Stairway to Heaven", artist: "Led Zeppelin", date: "2 hours ago" },
    { id: 2, title: "Wonderwall", artist: "Oasis", date: "Yesterday" },
    { id: 3, title: "Sweet Child O' Mine", artist: "Guns N' Roses", date: "3 days ago" },
    { id: 4, title: "Nothing Else Matters", artist: "Metallica", date: "1 week ago" },
  ]

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Recent Conversions</h2>

      <div className="grid gap-4">
        {recentItems.map((item) => (
          <Card key={item.id} className="overflow-hidden">
            <CardContent className="p-0">
              <div className="flex items-center border-b last:border-0">
                <div className="bg-purple-100 dark:bg-purple-900/20 p-4 flex items-center justify-center">
                  <Music className="h-8 w-8 text-purple-600 dark:text-purple-400" />
                </div>
                <div className="flex-1 p-4">
                  <div className="font-medium">{item.title}</div>
                  <div className="text-sm text-slate-500 dark:text-slate-400">{item.artist}</div>
                  <div className="flex items-center mt-1 text-xs text-slate-400 dark:text-slate-500">
                    <Clock className="h-3 w-3 mr-1" />
                    {item.date}
                  </div>
                </div>
                <div className="p-4 flex gap-2">
                  <Button size="sm" variant="ghost">
                    <ExternalLink className="h-4 w-4" />
                    <span className="sr-only">Open</span>
                  </Button>
                  <Button size="sm" variant="ghost">
                    <Download className="h-4 w-4" />
                    <span className="sr-only">Download</span>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {recentItems.length === 0 && (
        <div className="text-center py-12">
          <p className="text-slate-500 dark:text-slate-400">No recent conversions found</p>
        </div>
      )}
    </div>
  )
}
