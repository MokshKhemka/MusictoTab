"use client"

import { Button } from "@/components/ui/button"
import { ModeToggle } from "@/components/mode-toggle"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Menu, Music, User } from "lucide-react"
import Link from "next/link"
import { useState } from "react"

export function Header() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-white/80 backdrop-blur-sm dark:bg-slate-950/80">
      <div className="container flex h-16 items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-[240px] sm:w-[300px]">
              <nav className="flex flex-col gap-4 mt-8">
                <Link href="/" className="text-sm font-medium hover:underline">
                  Home
                </Link>
                <Link href="/pricing" className="text-sm font-medium hover:underline">
                  Pricing
                </Link>
                <Link href="/about" className="text-sm font-medium hover:underline">
                  About
                </Link>
                <Link href="/help" className="text-sm font-medium hover:underline">
                  Help
                </Link>
              </nav>
            </SheetContent>
          </Sheet>

          <Link href="/" className="flex items-center gap-2">
            <Music className="h-6 w-6 text-purple-600" />
            <span className="font-bold text-xl hidden sm:inline-block">Music to Tab</span>
          </Link>
        </div>

        <nav className="hidden md:flex items-center gap-6">
          <Link href="/" className="text-sm font-medium hover:text-purple-600 transition-colors">
            Home
          </Link>
          <Link href="/pricing" className="text-sm font-medium hover:text-purple-600 transition-colors">
            Pricing
          </Link>
          <Link href="/about" className="text-sm font-medium hover:text-purple-600 transition-colors">
            About
          </Link>
          <Link href="/help" className="text-sm font-medium hover:text-purple-600 transition-colors">
            Help
          </Link>
        </nav>

        <div className="flex items-center gap-2">
          <ModeToggle />
          {isLoggedIn ? (
            <Button variant="ghost" size="icon">
              <User className="h-5 w-5" />
              <span className="sr-only">User account</span>
            </Button>
          ) : (
            <Button onClick={() => setIsLoggedIn(true)}>Sign In</Button>
          )}
        </div>
      </div>
    </header>
  )
}
