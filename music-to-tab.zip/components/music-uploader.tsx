"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Mic, Youtube } from "lucide-react"
import { Progress } from "@/components/ui/progress"

export function MusicUploader() {
  const [isUploading, setIsUploading] = useState(false)
  const [progress, setProgress] = useState(0)
  const [youtubeUrl, setYoutubeUrl] = useState("")

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.length) return

    // Simulate upload progress
    setIsUploading(true)
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setIsUploading(false)
          return 100
        }
        return prev + 5
      })
    }, 200)
  }

  const handleYoutubeSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!youtubeUrl) return

    // Simulate processing
    setIsUploading(true)
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setIsUploading(false)
          return 100
        }
        return prev + 2
      })
    }, 100)
  }

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle>Upload Music</CardTitle>
        <CardDescription>Upload an audio file, paste a YouTube URL, or record directly</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="file" className="w-full">
          <TabsList className="grid grid-cols-3 mb-4">
            <TabsTrigger value="file">File</TabsTrigger>
            <TabsTrigger value="youtube">YouTube</TabsTrigger>
            <TabsTrigger value="record">Record</TabsTrigger>
          </TabsList>

          <TabsContent value="file" className="space-y-4">
            <div className="grid w-full items-center gap-1.5">
              <Label htmlFor="music-file">Upload audio file</Label>
              <div className="flex items-center gap-2">
                <Input
                  id="music-file"
                  type="file"
                  accept="audio/*"
                  onChange={handleFileUpload}
                  disabled={isUploading}
                  className="flex-1"
                />
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">Supported formats: MP3, WAV, FLAC (max 10MB)</p>
            </div>
          </TabsContent>

          <TabsContent value="youtube" className="space-y-4">
            <form onSubmit={handleYoutubeSubmit}>
              <div className="grid w-full items-center gap-1.5">
                <Label htmlFor="youtube-url">YouTube URL</Label>
                <div className="flex items-center gap-2">
                  <Input
                    id="youtube-url"
                    type="url"
                    placeholder="https://www.youtube.com/watch?v=..."
                    value={youtubeUrl}
                    onChange={(e) => setYoutubeUrl(e.target.value)}
                    disabled={isUploading}
                    className="flex-1"
                  />
                  <Button type="submit" size="sm" disabled={isUploading || !youtubeUrl}>
                    <Youtube className="h-4 w-4 mr-2" />
                    Extract
                  </Button>
                </div>
              </div>
            </form>
          </TabsContent>

          <TabsContent value="record" className="space-y-4">
            <div className="flex flex-col items-center justify-center py-8">
              <Button size="lg" className="rounded-full h-16 w-16 flex items-center justify-center">
                <Mic className="h-6 w-6" />
              </Button>
              <p className="mt-4 text-sm text-slate-500 dark:text-slate-400">Click to start recording</p>
            </div>
          </TabsContent>
        </Tabs>

        {isUploading && (
          <div className="mt-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span>Processing audio...</span>
              <span>{progress}%</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline">Clear</Button>
        <Button disabled={isUploading}>Convert to Tab</Button>
      </CardFooter>
    </Card>
  )
}
