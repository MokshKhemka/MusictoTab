import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MusicUploader } from "@/components/music-uploader"
import { TabViewer } from "@/components/tab-viewer"
import { Header } from "@/components/header"
import { RecentConversions } from "@/components/recent-conversions"
import { Settings } from "@/components/settings"

export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      <Header />

      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="max-w-5xl mx-auto">
          <h1 className="text-4xl font-bold text-center mb-2 bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-pink-600">
            Music to Tab Converter
          </h1>
          <p className="text-center text-slate-600 dark:text-slate-400 mb-8 max-w-2xl mx-auto">
            Transform your favorite songs into guitar tabs instantly with our AI-powered converter
          </p>

          <Tabs defaultValue="convert" className="w-full">
            <TabsList className="grid grid-cols-3 mb-8">
              <TabsTrigger value="convert">Convert Music</TabsTrigger>
              <TabsTrigger value="history">Recent Conversions</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
            </TabsList>

            <TabsContent value="convert" className="space-y-8">
              <div className="grid md:grid-cols-2 gap-8">
                <MusicUploader />
                <TabViewer />
              </div>
            </TabsContent>

            <TabsContent value="history">
              <RecentConversions />
            </TabsContent>

            <TabsContent value="settings">
              <Settings />
            </TabsContent>
          </Tabs>
        </div>
      </main>

      <footer className="border-t bg-white dark:bg-slate-950 py-6">
        <div className="container mx-auto px-4 text-center text-sm text-slate-500 dark:text-slate-400">
          <p>© 2025 Music to Tab. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}
